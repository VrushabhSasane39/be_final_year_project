from flask import Flask, render_template, jsonify
import json
import csv
import matplotlib.pyplot as plt
from io import BytesIO
import base64

app = Flask(__name__)

def calculate_score(answer_sheet_path, csv_filename):
    with open(answer_sheet_path) as json_file:
        answer_sheet = json.load(json_file)
        keywords = answer_sheet["keywords"]
        max_marks = answer_sheet["max_marks"]
        min_length = answer_sheet["min_length"]

    with open(csv_filename, 'r') as csv_file:
        reader = csv.reader(csv_file)
        words = list(reader)

    words = [word for sublist in words for word in sublist]
    keyword_matches = len(set(words) & set(keywords))
    keyword_marks_percentage = (keyword_matches / len(keywords)) * 100

    length_percentage = len(words) / min_length * 100
    length_marks_percentage = (len(words) / min_length) * 100
    final_score = (keyword_marks_percentage / 100) * (length_marks_percentage / 100) * max_marks

    return final_score, keyword_matches, length_percentage

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/blooms_scoring')
def blooms_scoring():
    answer_sheet_path = "answer_sheet.json"
    csv_filename = "fruits.csv"

    # Writing to CSV file
    data = ["Users", "should", "understand", "how", "automation", "enhances", "testing", "efficiency", "accelerates", "release", "cycles", "and", "contributes", "to", "overall", "software", "quality", "This", "level", "includes", "grasping", "concepts", "like", "test", "scripts", "automation", "frameworks", "and", "the", "advantages", "of", "automated", "testing."]
    with open(csv_filename, 'w', newline='') as csv_file:
        writer = csv.writer(csv_file)
        writer.writerow(data)

    print(f'The data has been saved to {csv_filename}.')

    # Example usage
    score, keyword_matches, length_percentage = calculate_score(answer_sheet_path, csv_filename)
    print(f"Marks Obtained: {score}")
    print(f"Number of Words Matched: {keyword_matches}")
    print(f"Length Percentage: {length_percentage}%")

    # Create a pie chart for keywords matched
    labels = ['Keywords Matched', 'Other Words']
    sizes = [keyword_matches, len(data) - keyword_matches]
    colors = ['gold', 'lightcoral']
    explode = (0.1, 0)  # explode 1st slice

    plt.figure(figsize=(10, 5))
    plt.subplot(1, 2, 1)  # Create a subplot for the pie chart
    plt.pie(sizes, explode=explode, labels=labels, colors=colors, autopct='%1.1f%%', shadow=True, startangle=140)
    plt.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle.
    plt.title('Keywords Matched vs Other Words')

    # Create a table with scores and percentages
    table_data = [['Metric', 'Value'],
                  ['Keywords Matched', keyword_matches],
                  ['Length Percentage', f'{length_percentage:.2f}%'],
                  ['Marks Obtained', f'{score:.2f}']]
    plt.subplot(1, 2, 2)  # Create a subplot for the table
    plt.axis('off')  # Turn off axis for the table
    plt.table(cellText=table_data, loc='center')

    # Save the plot to a BytesIO object
    image_stream = BytesIO()
    plt.savefig("static/plot.png", format='png', bbox_inches='tight')  # Save to the 'static' folder
    image_stream.seek(0)
    plt.close()

    # Convert the image to base64 for embedding in HTML
    image_base64 = base64.b64encode(image_stream.read()).decode('utf-8')

    return render_template('index.html', image_base64=image_base64)

if __name__ == '__main__':
    app.run(debug=True)
